function q = rotMatToQuat(R)
  % Input: rotation matrix
  % Output: corresponding quaternion [w x y z]
  
  % PLACEHOLDER FOR OUTPUT -> REPLACE WITH SOLUTION
  q = zeros(4,1);
end