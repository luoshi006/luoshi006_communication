% Add folders to path

% Add folders to path
addpath([pwd '/visualization']);
addpath([pwd '/visualization/STLs']);

addpath([pwd '/problems']);
addpath([pwd '/solutions/']);
addpath([pwd '/solutions/pcodes']);