function [ Dq ] = kinematicMotionControl(q, r_des, v_des)
% Inputs:
%  k          : current iteration.
%  q          : current configuration of the robot
% r_traj      : desired Cartesian trajectory
% Output: joint-space velocity command of the robot.

% Compute the updated joint velocities. This would be used for a velocity controllable robot
% TODO:
Dq = 0.1*ones(6,1);
end
